CREATE DATABASE aeropuerto CHARACTER set utf8mb4;

USE aeropuerto;

create table aerolinea(
id_aerolinea int not null primary key,
nombre varchar(100) not null
);

create table vuelo(
id_vuelo int not null primary key,
id_aerolinea int not null,
num_vuelo int not null,
origen varchar(100) not null,
destino varchar(100) not null,
fecha_salida datetime not null,
fecha_llegada datetime not null,
foreign key (id_aerolinea) references aerolinea(id_aerolinea) on delete cascade
);

create table avion(
id_avion int not null primary key,
id_aerolinea int not null,
modelo varchar(100) not null,
capacidad int not null,
foreign key (id_aerolinea) references aerolinea(id_aerolinea) on delete cascade
);

create table cliente(
id_cliente int not null primary key,
nombre varchar(100) not null,
apellido1 varchar(100) not null,
apellido2 varchar(100) default null,
nacimiento date not null
);

create table asiento(
fila int not null ,
letra enum ('A','B', 'C', 'D','E','F'),
id_avion int not null,
primary key(fila, letra, id_avion),
foreign key (id_avion) references avion(id_avion) on delete cascade

);
create table reserva(
id_reserva int not null primary key,
id_cliente int not null,
id_vuelo int not null,
fecha_reserva datetime not null ,
estado varchar(50) not null,
foreign key (id_cliente) references cliente(id_cliente) on delete cascade,
foreign key (id_vuelo) references vuelo(id_vuelo) on delete cascade
);

create table aeropuerto.reserva_asientos (
id_reserva int not null,
fila int not null,
letra enum('A','B','C','D','E','F') not null,
id_avion int not null,
constraint reserva_asientos_pk primary key (id_reserva,fila,letra,id_avion),
constraint reserva_asientos_FK foreign key (id_reserva) references aeropuerto.reserva(id_reserva) on delete cascade,
constraint reserva_asientos_FK_1 foreign key (fila,letra,id_avion) references aeropuerto.asiento(fila,letra,id_avion) on delete cascade,
constraint reserva_asientos_FK_2 foreign key (fila,letra,id_avion) references aeropuerto.asiento(fila,letra,id_avion) on delete cascade,
constraint reserva_asientos_FK_3 foreign key (fila,letra,id_avion) references aeropuerto.asiento(fila,letra,id_avion) on delete cascade
);